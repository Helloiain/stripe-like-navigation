import {css} from 'styled-components'

export const promoteLayer = css`
    will-change: transform;
`